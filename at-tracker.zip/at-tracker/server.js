// AT Project Tracker – single-file Node server. No database needed: data lives in ./data/db.json, uploads in ./data/uploads
const express = require('express'), multer = require('multer'), crypto = require('crypto');
const fs = require('fs'), path = require('path');
const DATA = path.join(__dirname, 'data'), UP = path.join(DATA, 'uploads'), DB = path.join(DATA, 'db.json');
fs.mkdirSync(UP, { recursive: true });

const PORT = process.env.PORT || 3000;
const PASSWORD = process.env.ADMIN_PASSWORD || 'changeme';
if (PASSWORD === 'changeme') console.warn('!! Set ADMIN_PASSWORD env var – using insecure default "changeme"');
const SECRET_FILE = path.join(DATA, '.secret');
if (!fs.existsSync(SECRET_FILE)) fs.writeFileSync(SECRET_FILE, crypto.randomBytes(32).toString('hex'));
const SECRET = fs.readFileSync(SECRET_FILE, 'utf8');

// ---------- storage ----------
const uid = () => crypto.randomBytes(6).toString('hex');
const now = () => new Date().toISOString();
const seed = () => {
  const c = (name, type, status, waitingOn, currency, contract, received, notes, nextAction) =>
    ({ id: uid(), name, type, status, waitingOn, currency, contract, openingReceived: received, contactName: '', email: '', phone: '', gst: '', notes, nextAction, updatedAt: '2026-08-29T00:00:00.000Z' });
  return {
    settings: { fx: 88 },
    clients: [
      c('Raniwala','Fixed Project','Payment Pending','Client','INR',692500,460860,'Raniwala 1881. ₹6,55,000 + ₹37,500 change request.',''),
      c('Raniwala Manpower','Monthly Retainer','Payment Pending','Client','INR',1165500,582750,'₹5,82,750 per month. July received; August invoice pending.','Requested the same, will get soon'),
      c('Propertycibil','Monthly Retainer','Payment Pending','Client','INR',400000,0,'Proptalk completed; inputs requested (29/08/2026). ~₹4–5 lakh monthly. Contract value is an ESTIMATE – replace with real invoice.','Only Aug month bill is pending'),
      c('Task Management','Fixed Project','Testing / Beta','Client','INR',155760,77880,'App shared for beta testing. Client meeting Sep 1st.','Get server details; invoice for remaining amount sent to accounts'),
      c('Innoveda','Fixed Project','In Development','Dev Team','INR',876136,0,'Waiting for dev team to complete the project.','Collab between Innovher and DIGL'),
      c('Advance Honda','Fixed Project','Waiting on Client','Client','INR',580000,290000,'CR mail sent 29-08-2026 (12 days + ₹75K). Awaiting approval.','CR ₹75,002 + GST. If not approved, collect remaining payment and go live.'),
      c('EBSR','Maintenance','Live / Maintenance','None','INR',44000,44000,'Website maintenance.',''),
      c('Amrapali','Fixed Project','Waiting on Client','Client','INR',90000,90000,'Waiting for them to buy GPU.',''),
      c('SkillsZA','Fixed Project','Payment Pending','Client','USD',8800,4840,'Client unavailable 10 Jun – 20 Aug 2026. Now checking the work.','Raise third milestone'),
      c('Indus Hospital','Pipeline','Pipeline','Client','INR',0,0,'Karan ji will share demo account of the running hospital management system.',''),
      c('Tissage Rugs','Pipeline','Pipeline','Internal','INR',0,0,'POC demo done. Meeting this weekend to finalise scope.','Share commercials after meeting'),
    ],
    invoices: [],
    activity: [{ at: now(), who: 'system', text: 'Initial import of 11 projects' }]
  };
};
let db = fs.existsSync(DB) ? JSON.parse(fs.readFileSync(DB, 'utf8')) : seed();
const save = () => { fs.writeFileSync(DB + '.tmp', JSON.stringify(db, null, 1)); fs.renameSync(DB + '.tmp', DB); };
const log = (text, clientId) => { db.activity.unshift({ at: now(), who: 'admin', text, clientId }); db.activity = db.activity.slice(0, 1000); };
if (!fs.existsSync(DB)) save();

// ---------- auth (signed cookie, no extra deps) ----------
const sign = v => crypto.createHmac('sha256', SECRET).update(v).digest('base64url');
const makeToken = () => { const exp = String(Date.now() + 7 * 864e5); return exp + '.' + sign(exp); };
const okToken = t => { if (!t) return false; const [exp, sig] = t.split('.'); return sig && sig === sign(exp) && Date.now() < +exp; };
const cookie = req => Object.fromEntries((req.headers.cookie || '').split(';').map(s => s.trim().split('=')).filter(a => a[0]));
const auth = (req, res, next) => okToken(cookie(req).at_session) ? next() : res.status(401).json({ error: 'login required' });
const tries = {};

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/login', (req, res) => {
  const ip = req.ip; tries[ip] = (tries[ip] || []).filter(t => Date.now() - t < 9e5);
  if (tries[ip].length >= 8) return res.status(429).json({ error: 'Too many attempts. Try again in 15 minutes.' });
  const a = Buffer.from(String(req.body.password || '')), b = Buffer.from(PASSWORD);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) { tries[ip].push(Date.now()); return res.status(401).json({ error: 'Wrong password' }); }
  res.setHeader('Set-Cookie', `at_session=${makeToken()}; HttpOnly; SameSite=Strict; Path=/; Max-Age=604800${req.secure ? '; Secure' : ''}`);
  res.json({ ok: true });
});
app.post('/api/logout', (req, res) => { res.setHeader('Set-Cookie', 'at_session=; HttpOnly; Path=/; Max-Age=0'); res.json({ ok: true }); });

// ---------- computed view ----------
const view = () => {
  const clients = db.clients.map(c => {
    const inv = db.invoices.filter(i => i.clientId === c.id);
    const paid = inv.filter(i => i.status === 'Paid').reduce((s, i) => s + i.amount, 0);
    const invoiced = inv.reduce((s, i) => s + i.amount, 0);
    const received = c.openingReceived + paid;
    return { ...c, invoiced, unpaidPI: invoiced - paid, received, pending: Math.max(c.contract - received, 0), pis: inv.length };
  });
  return { settings: db.settings, clients, invoices: db.invoices, activity: db.activity.slice(0, 200) };
};
app.get('/api/state', auth, (req, res) => res.json(view()));

// ---------- clients ----------
const FIELDS = { name: 's', type: 's', status: 's', waitingOn: 's', currency: 's', contract: 'n', openingReceived: 'n', contactName: 's', email: 's', phone: 's', gst: 's', notes: 's', nextAction: 's' };
const clean = (k, v) => FIELDS[k] === 'n' ? (Number(v) || 0) : String(v ?? '').trim().slice(0, 2000);
app.post('/api/clients', auth, (req, res) => {
  const c = { id: uid(), name: 'New client', type: 'Fixed Project', status: 'Pipeline', waitingOn: 'None', currency: 'INR', contract: 0, openingReceived: 0, contactName: '', email: '', phone: '', gst: '', notes: '', nextAction: '' };
  for (const k in FIELDS) if (k in req.body) c[k] = clean(k, req.body[k]);
  c.updatedAt = now(); db.clients.push(c); log(`Added client "${c.name}"`, c.id); save(); res.json(view());
});
app.put('/api/clients/:id', auth, (req, res) => {
  const c = db.clients.find(x => x.id === req.params.id); if (!c) return res.status(404).json({ error: 'not found' });
  const changes = [];
  for (const k in FIELDS) if (k in req.body) { const v = clean(k, req.body[k]); if (v !== c[k]) { changes.push(`${k}: "${c[k]}" → "${v}"`); c[k] = v; } }
  if (changes.length) { c.updatedAt = now(); log(`${c.name} updated – ${changes.join('; ').slice(0, 400)}`, c.id); save(); }
  res.json(view());
});

// ---------- upload + PI parsing ----------
const upload = multer({
  storage: multer.diskStorage({ destination: UP, filename: (r, f, cb) => cb(null, uid() + uid() + path.extname(f.originalname).toLowerCase().replace(/[^.a-z0-9]/g, '')) }),
  limits: { fileSize: 15 * 1024 * 1024 },
  fileFilter: (r, f, cb) => cb(null, /\.(pdf|png|jpe?g|xlsx?|docx?)$/i.test(f.originalname))
});
const num = s => parseFloat(String(s).replace(/,/g, ''));
function suggest(text, filename) {
  const out = { clientId: '', number: '', date: '', amount: 0, found: [] };
  const hay = (text + ' ' + filename).toLowerCase();
  let best = null;
  for (const c of db.clients) { const n = c.name.toLowerCase(); if (hay.includes(n) && (!best || n.length > best.name.length)) best = { id: c.id, name: n }; }
  if (best) { out.clientId = best.id; out.found.push('client'); }
  const pri = [/grand\s*total/i, /total\s*(amount\s*)?(payable|due)|amount\s*payable|net\s*payable|balance\s*due/i, /total\s*amount|invoice\s*total/i, /\btotal\b/i];
  for (const p of pri) {
    const re = new RegExp('(' + p.source + ')[^\\d\\n]{0,40}?(?:[₹$]|rs\\.?|inr|usd)?\\s*([\\d,]+(?:\\.\\d{1,2})?)', 'gi');
    const vals = [...text.matchAll(re)].map(m => num(m[m.length - 1])).filter(v => v > 0);
    if (vals.length) { out.amount = Math.max(...vals); out.found.push('amount'); break; }
  }
  const n = text.match(/(?:proforma\s*invoice|\bPI\b|invoice)\s*(?:no\.?|number|#)\s*[:.\-]?\s*([A-Za-z0-9][A-Za-z0-9\/\-_]{2,})/i);
  if (n) { out.number = n[1]; out.found.push('number'); }
  const d = text.match(/\b(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})\b/);
  if (d) { out.date = `${d[3]}-${d[2].padStart(2, '0')}-${d[1].padStart(2, '0')}`; out.found.push('date'); }
  return out;
}
app.post('/api/upload', auth, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Unsupported or missing file (PDF, image, Excel, Word up to 15 MB)' });
  let text = '';
  if (/\.pdf$/i.test(req.file.originalname)) {
    try { text = (await require('pdf-parse/lib/pdf-parse.js')(fs.readFileSync(req.file.path))).text || ''; } catch (e) { /* unreadable → manual entry */ }
  }
  res.json({ stored: req.file.filename, originalName: req.file.originalname, readable: !!text.trim(), suggestion: suggest(text, req.file.originalname) });
});
app.get('/files/:name', auth, (req, res) => {
  const inv = db.invoices.find(i => i.stored === req.params.name); if (!inv) return res.status(404).end();
  res.download(path.join(UP, path.basename(inv.stored)), inv.originalName);
});

// ---------- invoices (PI) ----------
app.post('/api/invoices', auth, (req, res) => {
  const b = req.body, c = db.clients.find(x => x.id === b.clientId);
  if (!c) return res.status(400).json({ error: 'Choose a client' });
  const amount = Number(b.amount); if (!(amount > 0)) return res.status(400).json({ error: 'Enter a valid amount' });
  const inv = { id: uid(), clientId: c.id, number: String(b.number || '').trim().slice(0, 60), date: String(b.date || now().slice(0, 10)), amount, status: 'Raised',
    stored: /^[a-f0-9]{24}(\.[a-z0-9]+)?$/.test(b.stored || '') ? b.stored : '', originalName: String(b.originalName || '').slice(0, 200), createdAt: now() };
  db.invoices.push(inv); c.updatedAt = now();
  log(`PI ${inv.number || '(no number)'} of ${c.currency} ${amount.toLocaleString('en-IN')} added to ${c.name}`, c.id); save(); res.json(view());
});
app.put('/api/invoices/:id', auth, (req, res) => {
  const i = db.invoices.find(x => x.id === req.params.id); if (!i) return res.status(404).json({ error: 'not found' });
  const c = db.clients.find(x => x.id === i.clientId);
  if (['Raised', 'Paid'].includes(req.body.status) && req.body.status !== i.status) {
    i.status = req.body.status; i.paidAt = i.status === 'Paid' ? now() : undefined; c.updatedAt = now();
    log(`PI ${i.number || i.id} of ${c.name} marked ${i.status}`, c.id); save();
  }
  res.json(view());
});
app.delete('/api/invoices/:id', auth, (req, res) => {
  const k = db.invoices.findIndex(x => x.id === req.params.id); if (k < 0) return res.status(404).json({ error: 'not found' });
  const [i] = db.invoices.splice(k, 1), c = db.clients.find(x => x.id === i.clientId);
  log(`PI ${i.number || i.id} removed from ${c ? c.name : '?'}`, i.clientId); save(); res.json(view());
});
app.put('/api/settings', auth, (req, res) => {
  const fx = Number(req.body.fx); if (fx > 0) { db.settings.fx = fx; log(`USD→INR rate set to ${fx}`); save(); }
  res.json(view());
});

app.listen(PORT, () => console.log(`AT Project Tracker running on http://localhost:${PORT}`));

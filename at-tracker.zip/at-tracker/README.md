# AT Project Tracker

Login-protected website: client list, PI (proforma invoice) upload, automatic amount tracking, timestamped activity log.

## How it works
- Upload a PI (PDF) → the server reads it and suggests **client, PI number, date and total amount** → you confirm → it is attached to that client.
- A PI counts as "awaiting payment" until you click **Mark paid**; then it moves into **Received** and **Pending** drops.
- Every change (client edit, PI added/paid/removed) is saved with a timestamp in *Recent activity* and in each client's *History*.
- Scanned PDFs / images / Excel / Word are stored, but the amount must be typed in.

## Run locally
```
npm install
ADMIN_PASSWORD="choose-a-strong-password" npm start      # http://localhost:3000
```

## Deploy on your domain (VPS, Node 18+)
1. Upload this folder, run `npm install --omit=dev`.
2. Keep it running: `ADMIN_PASSWORD="..." pm2 start server.js --name at-tracker` (`npm i -g pm2`), then `pm2 save`.
3. Point your domain to it with nginx (reverse proxy to port 3000) and enable HTTPS (certbot). HTTPS is important: the site holds financial data.
```
server { server_name tracker.yourdomain.com; client_max_body_size 20m;
  location / { proxy_pass http://127.0.0.1:3000; proxy_set_header X-Forwarded-Proto $scheme; proxy_set_header X-Forwarded-For $remote_addr; } }
```
cPanel hosts with "Setup Node.js App": set startup file `server.js`, add env var `ADMIN_PASSWORD`, run NPM install.
Plain PHP-only shared hosting cannot run this – you need Node.

## Data & backups
Everything lives in `data/` (`db.json` + `uploads/`). Back up that folder regularly. Do not delete `data/.secret` (login sessions).

## Security notes
Single shared password, 7-day session cookie, login rate-limited. For several users with separate logins, ask for a multi-user version.
